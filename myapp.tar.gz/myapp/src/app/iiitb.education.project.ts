import {Asset} from './org.hyperledger.composer.system';
import {Participant} from './org.hyperledger.composer.system';
import {Transaction} from './org.hyperledger.composer.system';
import {Event} from './org.hyperledger.composer.system';
// export namespace iiitb.education.project{
   export class Certificate extends Asset {
      certificateId: string;
      title: string;
      issuername: string;
      recipientname: string;
      issuedate: Date;
      issuer: Issuer;
      recipient: Recipient;
   }
   export abstract class User extends Participant {
      name: string;
      address: string;
      email: string;
      contact: string;
   }
   export class Issuer extends User {
      issuerId: string;
      issuedcert: walletcert[];
   }
   export class walletcert {
      certificateID: string;
      issuer: Issuer;
      recipient: Recipient;
      certificatelink: string;
      transactionID: string;
   }
   export class Recipient extends User {
      recipientId: string;
      wcert: walletcert[];
   }
   export class issuecertificate extends Transaction {
      certificate: Certificate;
      certificatehash: string;
      certfields: walletcert;
      issuer: Issuer;
      recipient: Recipient;
   }
// }
