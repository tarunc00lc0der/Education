import { Injectable } from '@angular/core';
import { DataService } from '../data.service';
import { Observable } from 'rxjs/Observable';
import { issuecertificate } from '../iiitb.education.project';
import 'rxjs/Rx';

// Can be injected into a constructor
@Injectable()
export class issuecertificateService {

	
		private NAMESPACE: string = 'issuecertificate';
	



    constructor(private dataService: DataService<issuecertificate>) {
    };

    public getAll(): Observable<issuecertificate[]> {
        return this.dataService.getAll(this.NAMESPACE);
    }

    public getTransaction(id: any): Observable<issuecertificate> {
      return this.dataService.getSingle(this.NAMESPACE, id);
    }

    public addTransaction(itemToAdd: any): Observable<issuecertificate> {
      return this.dataService.add(this.NAMESPACE, itemToAdd);
    }

    public updateTransaction(id: any, itemToUpdate: any): Observable<issuecertificate> {
      return this.dataService.update(this.NAMESPACE, id, itemToUpdate);
    }

    public deleteTransaction(id: any): Observable<issuecertificate> {
      return this.dataService.delete(this.NAMESPACE, id);
    }

}

